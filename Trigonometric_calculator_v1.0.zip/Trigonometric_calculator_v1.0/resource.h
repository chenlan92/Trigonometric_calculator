﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 Trigonometriccalculator.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TRIGONOMETRIC_CALCULATOR_DIALOG 102
#define IDS_STRING102                   102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     131
#define IDC_NUM1                        1000
#define IDC_ANGLE                       1004
#define IDC_SHOW                        1006
#define IDC_DEL                         1008
#define IDC_NUM4                        1011
#define IDC_NUM7                        1012
#define IDC_SIGN                        1013
#define IDC_NUM2                        1014
#define IDC_NUM5                        1015
#define IDC_NUM8                        1016
#define IDC_NUM0                        1017
#define IDC_NUM3                        1018
#define IDC_NUM6                        1019
#define IDC_NUM9                        1020
#define IDC_DOT                         1021
#define IDC_SIN                         1022
#define IDC_COS                         1023
#define IDC_ARCSIN                      1024
#define IDC_ARCTAN                      1025
#define IDC_AC                          1026
#define IDC_TYPE                        1027
#define IDC_SHOWTYPE                    1028
#define IDC_ERROR                       1029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
