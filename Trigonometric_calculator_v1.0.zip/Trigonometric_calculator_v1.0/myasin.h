#pragma once
#ifndef _MYASIN_H_ 
#define _MYASIN_H_ 
#include <stdio.h>
#include <math.h>
double myasin(double x);
#endif