#pragma once
#ifndef _MYSIN_H_ 
#define _MYSIN_H_ 
#include<stdio.h>
#include<math.h>
double mysin(double x);
#endif