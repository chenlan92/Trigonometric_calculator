﻿
// Trigonometric_calculatorDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "Trigonometric_calculator.h"
#include "Trigonometric_calculatorDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define PI        3.14159265358979323846

// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CTrigonometriccalculatorDlg 对话框



CTrigonometriccalculatorDlg::CTrigonometriccalculatorDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_TRIGONOMETRIC_CALCULATOR_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDB_BITMAP1);
	m_shownum = 0;
	m_datatype = FALSE;
}

void CTrigonometriccalculatorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CTrigonometriccalculatorDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_NUM1, &CTrigonometriccalculatorDlg::OnBnClickedNum1)
	ON_BN_CLICKED(IDC_NUM2, &CTrigonometriccalculatorDlg::OnBnClickedNum2)
	ON_BN_CLICKED(IDC_NUM3, &CTrigonometriccalculatorDlg::OnBnClickedNum3)
	ON_BN_CLICKED(IDC_NUM4, &CTrigonometriccalculatorDlg::OnBnClickedNum4)
	ON_BN_CLICKED(IDC_NUM5, &CTrigonometriccalculatorDlg::OnBnClickedNum5)
	ON_BN_CLICKED(IDC_NUM6, &CTrigonometriccalculatorDlg::OnBnClickedNum6)
	ON_BN_CLICKED(IDC_NUM7, &CTrigonometriccalculatorDlg::OnBnClickedNum7)
	ON_BN_CLICKED(IDC_NUM8, &CTrigonometriccalculatorDlg::OnBnClickedNum8)
	ON_BN_CLICKED(IDC_NUM9, &CTrigonometriccalculatorDlg::OnBnClickedNum9)
	ON_BN_CLICKED(IDC_NUM0, &CTrigonometriccalculatorDlg::OnBnClickedNum0)
	ON_BN_CLICKED(IDC_SIGN, &CTrigonometriccalculatorDlg::OnBnClickedSign)
	ON_BN_CLICKED(IDC_DOT, &CTrigonometriccalculatorDlg::OnBnClickedDot)
	ON_BN_CLICKED(IDC_SIN, &CTrigonometriccalculatorDlg::OnBnClickedSin)
	ON_BN_CLICKED(IDC_COS, &CTrigonometriccalculatorDlg::OnBnClickedCos)
	ON_BN_CLICKED(IDC_ARCSIN, &CTrigonometriccalculatorDlg::OnBnClickedArcsin)
	ON_BN_CLICKED(IDC_ARCTAN, &CTrigonometriccalculatorDlg::OnBnClickedArctan)
	ON_BN_CLICKED(IDC_DEL, &CTrigonometriccalculatorDlg::OnBnClickedDel)
	ON_BN_CLICKED(IDC_AC, &CTrigonometriccalculatorDlg::OnBnClickedAc)
	ON_BN_CLICKED(IDC_TYPE, &CTrigonometriccalculatorDlg::OnBnClickedType)
	ON_STN_CLICKED(IDC_SHOWTYPE, &CTrigonometriccalculatorDlg::OnStnClickedShowtype)
END_MESSAGE_MAP()


// CTrigonometriccalculatorDlg 消息处理程序

BOOL CTrigonometriccalculatorDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	ShowWindow(SW_MINIMIZE);
	SetDlgItemText(IDC_SHOWTYPE, L"ANG");
	SetDlgItemText(IDC_SHOW, L"0");
	// TODO: 在此添加额外的初始化代码

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CTrigonometriccalculatorDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CTrigonometriccalculatorDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CTrigonometriccalculatorDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CTrigonometriccalculatorDlg::OnBnClickedNum1()
{
	m_showstr += L"1";
	SetDlgItemText(IDC_SHOW, m_showstr);
	SetDlgItemText(IDC_ERROR, L"");
}


void CTrigonometriccalculatorDlg::OnBnClickedNum2()
{
	m_showstr += L"2";
	SetDlgItemText(IDC_SHOW, m_showstr);
	SetDlgItemText(IDC_ERROR, L"");
}


void CTrigonometriccalculatorDlg::OnBnClickedNum3()
{
	m_showstr += L"3";
	SetDlgItemText(IDC_SHOW, m_showstr);
	SetDlgItemText(IDC_ERROR, L"");
}


void CTrigonometriccalculatorDlg::OnBnClickedNum4()
{
	m_showstr += L"4";
	SetDlgItemText(IDC_SHOW, m_showstr);
	SetDlgItemText(IDC_ERROR, L"");
}


void CTrigonometriccalculatorDlg::OnBnClickedNum5()
{
	m_showstr += L"5";
	SetDlgItemText(IDC_SHOW, m_showstr);
	SetDlgItemText(IDC_ERROR, L"");
}


void CTrigonometriccalculatorDlg::OnBnClickedNum6()
{
	m_showstr += L"6";
	SetDlgItemText(IDC_SHOW, m_showstr);
	SetDlgItemText(IDC_ERROR, L"");
}


void CTrigonometriccalculatorDlg::OnBnClickedNum7()
{
	m_showstr += L"7";
	SetDlgItemText(IDC_SHOW, m_showstr);
	SetDlgItemText(IDC_ERROR, L"");
}


void CTrigonometriccalculatorDlg::OnBnClickedNum8()
{
	m_showstr += L"8";
	SetDlgItemText(IDC_SHOW, m_showstr);
	SetDlgItemText(IDC_ERROR, L"");
}


void CTrigonometriccalculatorDlg::OnBnClickedNum9()
{
	m_showstr += L"9";
	SetDlgItemText(IDC_SHOW, m_showstr);
	SetDlgItemText(IDC_ERROR, L"");
}


void CTrigonometriccalculatorDlg::OnBnClickedNum0()
{
	m_showstr += L"0";
	SetDlgItemText(IDC_SHOW, m_showstr);
	SetDlgItemText(IDC_ERROR, L"");
}


void CTrigonometriccalculatorDlg::OnBnClickedSign()
{
	if (m_showstr.Find(L"-") != -1) {
		m_showstr = m_showstr.Right(m_showstr.GetLength() - 1);
	}	
	else {
		m_showstr = L"-" + m_showstr;
	}
	SetDlgItemText(IDC_SHOW, m_showstr);
	SetDlgItemText(IDC_ERROR, L"");
}


void CTrigonometriccalculatorDlg::OnBnClickedDot()
{
	SetDlgItemText(IDC_ERROR, L"");
	if (m_showstr.Find(L".") != -1)
		return;
	
	m_showstr += L".";
	SetDlgItemText(IDC_SHOW, m_showstr);
}


void CTrigonometriccalculatorDlg::OnBnClickedSin()
{
	SetDlgItemText(IDC_ERROR, L"");
	m_shownum = _wtof(m_showstr);
	if (m_datatype == FALSE) {
		m_shownum = (m_shownum / 180) * PI;
	}//角度转弧度

	m_shownum = snowsin(m_shownum);

	m_showstr.Format(L"%lf", m_shownum);
	SetDlgItemText(IDC_SHOW, m_showstr);
}


void CTrigonometriccalculatorDlg::OnBnClickedCos()
{
	SetDlgItemText(IDC_ERROR, L"");
	m_shownum = _wtof(m_showstr);
	if (m_datatype == FALSE) {
		m_shownum = (m_shownum / 180) * PI;
	}//角度转弧度

	m_shownum = snowcos(m_shownum);

	m_showstr.Format(L"%lf", m_shownum);
	SetDlgItemText(IDC_SHOW, m_showstr);
}


void CTrigonometriccalculatorDlg::OnBnClickedArcsin()
{
	m_shownum = _wtof(m_showstr);
	if (m_shownum < -1 || m_shownum > 1) {
		SetDlgItemText(IDC_SHOW, m_showstr);
		SetDlgItemText(IDC_ERROR, L"ERROR");
	}
	else {

		m_shownum = snowarcsin(m_shownum);

		if (m_datatype == FALSE) {
			m_shownum = (m_shownum / PI) * 180;
		}//弧度转角度

		m_showstr.Format(L"%lf", m_shownum);
		SetDlgItemText(IDC_SHOW, m_showstr);
		SetDlgItemText(IDC_ERROR, L"");
	}
}


void CTrigonometriccalculatorDlg::OnBnClickedArctan()
{
	SetDlgItemText(IDC_ERROR, L"");
	m_shownum = _wtof(m_showstr);

	m_shownum = snowarctan(m_shownum);

	if (m_datatype == FALSE) {
		m_shownum = (m_shownum / PI) * 180;
	}//弧度转角度

	m_showstr.Format(L"%lf", m_shownum);
	SetDlgItemText(IDC_SHOW, m_showstr);
}


void CTrigonometriccalculatorDlg::OnBnClickedDel()
{
	if (m_showstr.IsEmpty()) {
		SetDlgItemText(IDC_SHOW, L"0");
	}
	else if (m_showstr.GetLength() == 1) {
		m_showstr = m_showstr.Left(m_showstr.GetLength() - 1);
		SetDlgItemText(IDC_SHOW, L"0");
	}
	else {
		m_showstr = m_showstr.Left(m_showstr.GetLength() - 1);
		SetDlgItemText(IDC_SHOW, m_showstr);
	}
}


void CTrigonometriccalculatorDlg::OnBnClickedAc()
{
	m_showstr.Empty();
	m_shownum = 0;
	SetDlgItemText(IDC_SHOW, L"0");
}


void CTrigonometriccalculatorDlg::OnBnClickedType()
{
	m_shownum = _wtof(m_showstr);
	if (m_datatype == FALSE) {
		m_datatype = TRUE;
		m_shownum = (m_shownum / 180) * 3.1415926;
		SetDlgItemText(IDC_SHOWTYPE, L"RAD");
	}
	else{
		m_datatype = FALSE;
		m_shownum = (m_shownum / 3.1415926) * 180;
		SetDlgItemText(IDC_SHOWTYPE, L"ANG");
	}
	m_showstr.Format(L"%lf", m_shownum);
	SetDlgItemText(IDC_SHOW, m_showstr);
}


void CTrigonometriccalculatorDlg::OnStnClickedShowtype()
{
	// TODO: 在此添加控件通知处理程序代码
}



//以下为实现三角函数计算函数
//阶乘
double factorial(double n) {
	if (n <= 1) {
		return n;
	}
	else {
		return n * factorial(n - 1);
	}
}


//下面为求绝对值函数
double myabs(double num1)
{
	return((num1 > 0) ? num1 : -num1);
}

//下面为求sin(x)的值

double snowsin(double num2)
{
	int i = 1, negation = 1;//取反
	double sum;
	double index = num2;//指数
	double Factorial = 1;//阶乘
	double TaylorExpansion = num2;//泰勒展开式求和
	do
	{
		Factorial = Factorial * ((__int64)i + 1) * ((__int64)i + 2);//求阶乘
		index *= num2 * num2;//求num2的次方
		negation = -negation;//每次循环取反
		sum = index / Factorial * negation;
		TaylorExpansion += sum;
		i += 2;
	} while (myabs(sum) > 1e-15);
	return(TaylorExpansion);
}

//求cos
double snowcos(double x)
{
	double sin = snowsin(x);//先求出SIN的值
	double cos = 1 - sin * sin;//在通过公式减去SIN

	return sqrt(cos);//开方
}

//求arcsin x的范围要变化为（-1，1）
double snowarcsin(double x)
{
	double result = x, result_a = 1.0f, result_b = 1.0f, result_c = 1.0f;//定义变量
	unsigned int i = 0, ii = 0;//此方法有一定的精度误差，越靠近1精度误差越大
	for (i = 0; i < 1000; i++)
	{
		for (ii = 0; ii < (2 * i + 1); ii++)
		{
			result_a *= (double)(2 * ii + 1) / (double)(2 * ii + 2);
			result_b *= (x * x);
		}
		result_b = x;
		result_c = result_a / (double)(ii + 2);
		result += (double)(result_c) * (double)result_b;
		result_a = 1.0f; result_a = 1.0f;

	}
	return result;

}

//求arctan，输入数，求出弧度
double snowarctan(double x)
{
	double sqr = x * x;
	double e = x;
	double r = 0;
	int i = 1;
	if (e >= -1 && e <= 1)//泰勒级数
	{
		while (fabs(e / i) > 1e-7)
		{
			double f = e / i;
			r = (i % 4 == 1) ? r + f : r - f;
			e = e * sqr;
			i += 2;
		}
	}
	if (e <= -1 || e >= 1)//arctan(x)+arctan(1/x)=π/2
	{
		e = 1 / e;
		double h = e * e;
		while (fabs(e / i) > 1e-7)
		{
			double f = e / i;
			r = (i % 4 == 1) ? r + f : r - f;
			e = e * h;
			i += 2;
		}
		if (e > 0)
			r = PI / 2 - r;
		else
			r = -PI / 2 - r;
	}
	return r;
}
